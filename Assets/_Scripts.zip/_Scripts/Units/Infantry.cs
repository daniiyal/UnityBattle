using UnityEngine;

public class Infantry : Unit, IClonable 
{
    public Infantry(ScriptableUnit scriptableUnit) : base(scriptableUnit)
    {
    }

    public IUnit Clone()
    {
        var unitClone = (Unit)MemberwiseClone();
        return unitClone;
    }
}
