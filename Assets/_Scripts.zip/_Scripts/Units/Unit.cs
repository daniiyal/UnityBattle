﻿using System.Collections;
using UnityEngine;

public class Unit : MonoBehaviour, IUnit
{
    [SerializeField] private ScriptableUnit _scriptableUnit;
    [SerializeField] private GridInteractor _gridInteractor;
    [SerializeField] private Tile _currentTile;

    [SerializeField] private Animator animator;

    protected Unit(ScriptableUnit scriptableUnit)
    {
        _scriptableUnit = scriptableUnit;
        SetStats(scriptableUnit.BaseStats);
    }
    public Stats Stats { get; set; }

    public void SetStats(Stats stats) => Stats = stats;

    public void TakeDamage(int damage)
    {
        var _stats = Stats;

        _stats.Health -= damage;
        SetStats(_stats);

        //Debug.Log($"{this} - {Stats.Health}");

    }

    public Faction GetFaction()
    {
        return _scriptableUnit.Faction;
    }

    //private IEnumerator MoveObject(Vector3 target)
    //{

    //    yield return null;

    //    while (Vector3.Distance(transform.position, target) > 0.1f)
    //    {
    //        float speed = 1 * Time.deltaTime;
    //        transform.position = Vector3.Lerp(transform.position, target, speed);
    //    }
    //}

    public void SetPosition(Vector3 position)
    {
        //MoveObject(position);

        transform.position = position;
    }

    public Vector3 GetPosition()
    {
        return transform.position;
    }

    public void Die()
    {
        animator.SetTrigger("Die");
        StartCoroutine(OnCompleteDieAnimation(animator.GetCurrentAnimatorStateInfo(0).length));
    }

    IEnumerator OnCompleteDieAnimation(float time)
    {
        yield return new WaitForSeconds(time);
        this.gameObject.SetActive(false);
        _currentTile.Unit = null;
    }

    public GameObject GetPrefab()
    {
        return _scriptableUnit.UnitPrefab;
    }

    public bool isAlive => Stats.Health > 0;

    public bool isDamaged => Stats.Health > Stats.MaxHealth;

    public void InitializeTile()
    {
        Ray ray = new Ray(transform.position, Vector3.down);

        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, 1000f))
        {
            if (hit.collider.GetComponent<Tile>())
            {
                transform.position = new Vector3(hit.transform.position.x, hit.transform.position.y + 0.1f, hit.transform.position.z);
                var tile = hit.collider.GetComponent<Tile>();
                tile.Unit = this;
                _currentTile = tile;

                _gridInteractor = tile.GridInteractor;

            }
        }

    }

    public Tile GetCurrentTile()
    {
        return _currentTile;
    }

    public void SetCurrentTile(Tile tile)
    {
        _currentTile = tile;
    }

    public Animator GetAnimator()
    {
        return animator;
    }
}