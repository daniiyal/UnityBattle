﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Healer : Unit, ISpecialAbility
{
    public Healer(ScriptableUnit scriptableUnit) : base(scriptableUnit)
    {
    }

    public void DoSpecialAction()
    {
        System.Random random = new System.Random();
        var chance = random.Next(100 / Stats.Chance) == 0;

        if (chance)
        {
            var targetUnit = GetTargetUnit();
            if (targetUnit != null)
            {
                Debug.Log(targetUnit);


                var command = new HealCommand(this, targetUnit, Stats.AttackPower);
                GameManager.Instance.commandManager.Execute(command);
            }
        }
    }

    private IHealable GetTargetUnit()
    {
        var gridInteractor = GameManager.Instance.gridInteractor;
        int index = gridInteractor.GridRepository.Tiles.IndexOf(GetCurrentTile());
        IHealable targetUnit;

        var targetTiles = new List<Tile>
            {
            gridInteractor.GridRepository.Tiles[index - 9],
            gridInteractor.GridRepository.Tiles[index + 9],
            gridInteractor.GridRepository.Tiles[index + 1],
            gridInteractor.GridRepository.Tiles[index - 1]
            };

        foreach (var tile in targetTiles.ToList())
        {
            if (tile.Unit == null || !(tile.Unit is IHealable))
            {
                targetTiles.Remove(tile);
            }
        }

        if (targetTiles.Count == 0)
            return null;
        System.Random random = new System.Random();
        var randomIndex = random.Next(targetTiles.Count);

        targetUnit = targetTiles[randomIndex].Unit as IHealable;
        return targetUnit;
    }
}