﻿using Assets._Scripts.Units.UnitCreators;
using System.Linq;
using UnityEngine;

public class InfantryUnitCreator : IUnitCreator
{

    public IUnit CreateUnit(Faction faction)
    {
        ScriptableUnit[] scriptableUnits;
        if (faction == Faction.Left)
            scriptableUnits = Resources.LoadAll<ScriptableUnit>("ScriptableUnits/LeftUnits");
        else
            scriptableUnits = Resources.LoadAll<ScriptableUnit>("ScriptableUnits/RightUnits");

        ScriptableUnit infantryType = scriptableUnits.Where(unitType => unitType.UnitType == UnitType.Infantry).First();
        return new Infantry(infantryType);

    }
}

