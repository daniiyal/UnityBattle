﻿using Assets._Scripts.Units.UnitCreators;
using System.Linq;
using UnityEngine;

public class ArcherUnitCreator : IUnitCreator
{

    public IUnit CreateUnit(Faction faction)
    {
        ScriptableUnit[] scriptableUnits;
        if (faction == Faction.Left)
            scriptableUnits = Resources.LoadAll<ScriptableUnit>("ScriptableUnits/LeftUnits");
        else
            scriptableUnits = Resources.LoadAll<ScriptableUnit>("ScriptableUnits/RightUnits");
  
        ScriptableUnit archerType = scriptableUnits.Where(unitType => unitType.UnitType == UnitType.Archer).First();
       

        return new Archer(archerType);

    }
}