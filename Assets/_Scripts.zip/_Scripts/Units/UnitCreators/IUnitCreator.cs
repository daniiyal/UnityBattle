﻿
namespace Assets._Scripts.Units.UnitCreators
{
    public interface IUnitCreator
    {
        IUnit CreateUnit(Faction faction);

    }
}
