﻿using System.Collections;
using UnityEngine;

public interface IUnit
{
    public Stats Stats { get; set; }
    public void SetStats(Stats stats);

    public GameObject GetPrefab();

    public Tile GetCurrentTile();
    public void SetCurrentTile(Tile tile);

    public void SetPosition(Vector3 position);

    public Vector3 GetPosition();
    public Faction GetFaction();

    public Animator GetAnimator();
    bool isAlive { get; }
    bool isDamaged { get; }

    void TakeDamage(int damage);
    public void Die();
    public void InitializeTile();
}

