﻿
public interface IClonable
{
    IUnit Clone();
}

