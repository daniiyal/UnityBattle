﻿
using UnityEngine;

public interface ISpecialAbility
{
    void DoSpecialAction();
}

