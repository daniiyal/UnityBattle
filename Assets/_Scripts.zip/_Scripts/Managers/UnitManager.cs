using System.Collections.Generic;
using UnityEngine;

public class UnitManager : MonoBehaviour
{
    public List<GameObject> SpawnUnits3VS3(IArmy Army)
    {

        float i = 2.2f;
        float j = 3.3f;
        GameObject unit_prefab;

        var unitGameObjects = new List<GameObject>();


        foreach (var unit in Army.Units)
        {
            if (Army.Faction == Faction.Left)
                unit_prefab = Instantiate(unit.GetPrefab(), new Vector3(11 + i, 1, j), Quaternion.Euler(0, 270, 0));
            else
                unit_prefab = Instantiate(unit.GetPrefab(), new Vector3(11 - i, 1, j), Quaternion.Euler(0, 90, 0));

            unit_prefab.GetComponent<IUnit>().InitializeTile();
            unit_prefab.GetComponent<IUnit>().SetStats(unit.Stats);

            unitGameObjects.Add(unit_prefab);

            if (j != 5.5f)
                j += 1.1f;
            else
            {
                i += 1.1f;
                j = 3.3f;
            }
                
        }

        return unitGameObjects;
    }

    public List<GameObject> SpawnUnits1VS1(IArmy Army)
    {
        float i = 2.2f;
        GameObject unit_prefab;

        var unitGameObjects = new List<GameObject>();

        foreach (var unit in Army.Units)
        {
            if (Army.Faction == Faction.Left)
                unit_prefab = Instantiate(unit.GetPrefab(), new Vector3(11 + i, 1, 4.4f), Quaternion.Euler(0, 270, 0));
            else
                unit_prefab = Instantiate(unit.GetPrefab(), new Vector3(11 - i, 1, 4.4f), Quaternion.Euler(0, 90, 0));

            unit_prefab.GetComponent<IUnit>().InitializeTile();
            unit_prefab.GetComponent<IUnit>().SetStats(unit.Stats);

            unitGameObjects.Add(unit_prefab);

            i += 1.1f;

        }

        return unitGameObjects;
    }


    public GameObject SpawnUnit(IUnit unit, Vector3 pos)
    {
        GameObject unit_prefab;
        Debug.Log(unit.GetPrefab());
        if (unit.GetFaction() == Faction.Left)
            unit_prefab = Instantiate(unit.GetPrefab(), pos, Quaternion.Euler(0, 270, 0));
        else
            unit_prefab = Instantiate(unit.GetPrefab(), pos, Quaternion.Euler(0, 90, 0));

        unit_prefab.GetComponent<IUnit>().InitializeTile();
        unit_prefab.GetComponent<IUnit>().SetStats(unit.Stats);


        return unit_prefab;
    }

    public void DestroyUnit(GameObject unit)
    {
        Destroy(unit);
    }

}
