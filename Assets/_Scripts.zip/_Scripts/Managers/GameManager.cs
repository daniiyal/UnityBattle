using UnityEngine;

public class GameManager : MonoBehaviour // ��������
{
    public static GameManager Instance;

    public GridManager gridManager;
    public GridInteractor gridInteractor;

    public UnitManager unitManager;

    public CommandManager commandManager;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this.gameObject);
            return;
        }
        Destroy(this.gameObject);
    }
    void Start() => ChangeState(GameState.StartGame);

    //public static event Action<GameState> OnBeforeChanged;
    //public static event Action<GameState> OnAfterStateChanged;

    public IStrategy Strategy;
    public IArmy LeftArmy { get; private set; }
    public IArmy RightArmy { get; private set; }



    public GameState State { get; private set; }

    public void ChangeState(GameState newState)
    {
        State = newState;
        Debug.Log(State);
        switch (newState)
        {
            case GameState.StartGame:
                HandleStarting();
                break;
            case GameState.SpawnLeftUnits:
                HandleSpawningLeftUnits();
                break;
            case GameState.SpawnRightUnits:
                HandleSpawningRightUnits();
                break;
            case GameState.NextTurn:
                break;
            case GameState.Decide:
                break;
            case GameState.WinScreen:
                break;
            default:
                break;


        }
    }

    private void HandleSpawningLeftUnits()
    {
        //������� ����� �����
        var factory = new ArmyFactory();

        LeftArmy = new Army(Faction.Left, factory, 50);

        LeftArmy.unitGameObjects = Strategy.spawnUnits(LeftArmy);


        ChangeState(GameState.SpawnRightUnits);
    }

    private void HandleSpawningRightUnits()
    {
        //������� ������ �����
        var factory = new ArmyFactory();

        RightArmy = new Army(Faction.Right, factory, 50);
        RightArmy.unitGameObjects = Strategy.spawnUnits(RightArmy);


        ChangeState(GameState.NextTurn);
    }


    public void NextTurn()
    {

        MeleeAttack();
        SpecialAbilityActions();
        CollectDeadUnits();

        commandManager.EndTurn();
    }

    private void SpecialAbilityActions()
    {
        var queue = Strategy.GetUnitsWithSpecialAbility(LeftArmy, RightArmy);

        foreach (var unit in queue)
        {
            unit.GetComponent<ISpecialAbility>().DoSpecialAction();
        }
    }

    private void CollectDeadUnits()
    {
        LeftArmy.CollectDeadUnits();
        RightArmy.CollectDeadUnits();
    }

    private void MeleeAttack()
    {
        var queue = Strategy.MeleeAttackOpponentQueue(LeftArmy, RightArmy);
        foreach (var opponent in queue)
        {
            Attack(opponent.LeftUnit);
            Attack(opponent.RightUnit);
        }
    }

    private void Attack(GameObject unitGameObject)
    {
        var unit = unitGameObject.GetComponent<IUnit>();
        var currentTile = unit.GetCurrentTile();
        var targetTile = GetTargetTile(unit);

        ICommand command;
        if (targetTile.Unit != null)
            command = new AttackCommand(unit, targetTile.Unit, unit.Stats.AttackPower);
        else
            command = new TravelCommand(unit, currentTile, targetTile);

        commandManager.Execute(command);
    }

    private Tile GetTargetTile(IUnit unit)
    {

        var currentTile = unit.GetCurrentTile();
        var currentTileIndex = gridInteractor.GridRepository.Tiles.IndexOf(currentTile);

        Tile targetTile;
        if (unit.GetFaction() == Faction.Left)
            targetTile = gridInteractor.GridRepository.Tiles[currentTileIndex - 9 * unit.Stats.TravelDistance];
        else
            targetTile = gridInteractor.GridRepository.Tiles[currentTileIndex + 9 * unit.Stats.TravelDistance];


        return targetTile;
    }

    private void HandleStarting()
    {
        // GridManager.Instance.GenerateGrid();

        //var gridGenerator = GetComponent<GridManager>();
        gridManager.GenerateGrid();

        Strategy = new Strategy3VS3();
        commandManager = new CommandManager();
        ChangeState(GameState.SpawnLeftUnits);
    }
}


public enum GameState
{
    StartGame,
    SpawnLeftUnits,
    SpawnRightUnits,
    NextTurn,
    Decide,
    WinScreen
}