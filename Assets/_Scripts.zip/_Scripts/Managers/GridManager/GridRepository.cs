using System.Collections.Generic;
using UnityEngine;

public class GridRepository : MonoBehaviour
{
    public List<Tile> Tiles = new List<Tile>();
    public Tile SelectedTile;
}
