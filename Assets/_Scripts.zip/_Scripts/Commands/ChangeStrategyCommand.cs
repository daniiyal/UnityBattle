﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class ChangeStrategyCommand : ICommand
{
    private IStrategy initStrategy;
    private IStrategy targetStrategy;

    public ChangeStrategyCommand(IStrategy initStrategy, IStrategy targetStrategy)
    {
        this.initStrategy = initStrategy;
        this.targetStrategy = targetStrategy;
    }



    public void Execute()
    {
        GameManager.Instance.Strategy = targetStrategy;
    }

    public void Undo()
    {
        GameManager.Instance.Strategy = initStrategy;
    }
}
