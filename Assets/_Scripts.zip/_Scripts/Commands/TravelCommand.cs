﻿using System;
using UnityEngine;

public class TravelCommand : ICommand
{

    IUnit unit;
    Tile currentTile;
    Tile targetTile;
    int currentTileIndex;
    GridRepository gridRepository;

    public TravelCommand(IUnit unit, Tile currentTile, Tile targetTile)
    {
        this.unit = unit;
        this.targetTile = targetTile;
        this.currentTile = currentTile;
        gridRepository = GameManager.Instance.gridInteractor.GridRepository;
        currentTileIndex = gridRepository.Tiles.IndexOf(currentTile);
    }

    public void Execute()
    {
        //Debug.Log(unit);

        if (unit.GetFaction() == Faction.Left)
            targetTile = gridRepository.Tiles[currentTileIndex - 9 * unit.Stats.TravelDistance];
        else
            targetTile = gridRepository.Tiles[currentTileIndex + 9 * unit.Stats.TravelDistance];

        if (targetTile.Unit == null)
        {
            Move(targetTile);
        }
    }

    private void Move(Tile tile)
    {

        unit.SetPosition(new Vector3(   tile.transform.position.x, 
                                        tile.transform.position.y + 0.1f, 
                                        tile.transform.position.z));

        
        currentTile.Unit = null;
        currentTileIndex = gridRepository.Tiles.IndexOf(tile);



        tile.Unit = (Unit)unit;
        unit.SetCurrentTile(tile);
        currentTile = tile;
        
    }

    public void Undo()
    {
        Debug.Log(unit);

        if (unit.GetFaction() == Faction.Left)
            targetTile = gridRepository.Tiles[currentTileIndex + 9 * unit.Stats.TravelDistance];
        else
            targetTile = gridRepository.Tiles[currentTileIndex - 9 * unit.Stats.TravelDistance];
       
        if (targetTile.Unit == null)
        {
            Move(targetTile);
        }
    }
}
