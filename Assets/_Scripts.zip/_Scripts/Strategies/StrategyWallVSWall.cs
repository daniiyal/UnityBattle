﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

public class StrategyWallVSWall : IStrategy
{

    public List<MeleeOpponents> MeleeAttackOpponentQueue(IArmy FirstArmy, IArmy SecondArmy)
    {

		var firstArmyUnitsCount = FirstArmy.Units.Count;
		var secondArmyUnitsCount = SecondArmy.Units.Count;

		var minCount = Math.Min(firstArmyUnitsCount, secondArmyUnitsCount);


		var attackQueue = new List<MeleeOpponents>();

		for (int i = 0; i < minCount; i++)
		{
			var opponents = new MeleeOpponents(FirstArmy.unitGameObjects[i], SecondArmy.unitGameObjects[i]);
			attackQueue.Add(opponents);
		}

		return attackQueue;
	}

    public List<GameObject> GetUnitsWithSpecialAbility(IArmy FirstArmy, IArmy SecondArmy)
    {
        var specialUnits = new List<GameObject>();

        var firstArmyUnitsCount = FirstArmy.Units.Count;
		var secondArmyUnitsCount = SecondArmy.Units.Count;

        if(firstArmyUnitsCount > secondArmyUnitsCount)
        {
            var startIndex = firstArmyUnitsCount - secondArmyUnitsCount;
            for (int i = startIndex; i < FirstArmy.unitGameObjects.Count; i++)
            {
                var unit = FirstArmy.unitGameObjects[i];
                if (unit.GetComponent<IUnit>() is ISpecialAbility)
                {
                    specialUnits.Add(unit);
                }
            }
        }
        else
        {
            var startIndex = secondArmyUnitsCount - firstArmyUnitsCount;

            for (int i = startIndex; i < SecondArmy.unitGameObjects.Count; i++)
            {
                var unit = SecondArmy.unitGameObjects[i];
                if (unit.GetComponent<IUnit>() is ISpecialAbility)
                {
                    specialUnits.Add(unit);
                }
            }
        }

        return specialUnits;

    }

    public List<GameObject> spawnUnits(IArmy army)
    {
        throw new NotImplementedException();
    }
}