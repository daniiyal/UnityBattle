﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Strategy3VS3 : IStrategy
{

    public List<MeleeOpponents> MeleeAttackOpponentQueue(IArmy FirstArmy, IArmy SecondArmy)
    {

        var attackQueue = new List<MeleeOpponents>();


        var z = 3.3f;

        for (int i = 0; i < 3; i++)
        {
            var unit_left = FirstArmy.unitGameObjects.Where(x => x.GetComponent<IUnit>().GetPosition().z == z).FirstOrDefault();
            var unit_right = SecondArmy.unitGameObjects.Where(x => x.GetComponent<IUnit>().GetPosition().z == z).FirstOrDefault();
            if (unit_left != null && unit_right != null)
            {
                var opponents = new MeleeOpponents(unit_left, unit_right);
                attackQueue.Add(opponents);
            }
          
            z += 1.1f;
        }

        return attackQueue;
    }


    public List<GameObject> GetUnitsWithSpecialAbility(IArmy FirstArmy, IArmy SecondArmy)
    {
        var specialUnits = new List<GameObject>();


        var z = 3.3f;

        for (int i = 0; i < 3; i++)
        {
            var unit_left = FirstArmy.unitGameObjects.Where(x => x.GetComponent<IUnit>().GetPosition().z == z &&
                                                                 x.GetComponent<IUnit>() is ISpecialAbility).Skip(1);
            var unit_right = SecondArmy.unitGameObjects.Where(x => x.GetComponent<IUnit>().GetPosition().z == z &&
                                                              x.GetComponent<IUnit>() is ISpecialAbility).Skip(1);
            if (unit_left != null && unit_right != null)
            {
                foreach(var unit in unit_left)
                {
                    specialUnits.Add(unit);
                }
                foreach (var unit in unit_right)
                {
                    specialUnits.Add(unit);
                }
            }

            z += 1.1f;
        }

        return specialUnits;
    }

    public List<GameObject> spawnUnits(IArmy army)
    {
        return GameManager.Instance.unitManager.SpawnUnits3VS3(army);
    }
}
